package ec.edu.espe.ms_clientes.model;

public enum Genero {
    Femenino,Masculino
}
