package ec.edu.espe.ms_clientes.model;

public enum MarcaAutomovil {

    Kia, Chevrolet, Toyota
}
