package ec.edu.espe.ms_clientes.model;

public enum TipoAutomovil {
    SUV,
    Crossover,
    Sedan,
    Convertible,
    Minivan,
    Deportivo,
    Familiar,
    Limousine,
}
