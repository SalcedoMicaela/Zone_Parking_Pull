package ec.edu.espe.ms_clientes.model;

public enum MarcaMoto {
    YAMAHA,
    HONDA,
    SUZUKI,
    KAWASAKI,
}
