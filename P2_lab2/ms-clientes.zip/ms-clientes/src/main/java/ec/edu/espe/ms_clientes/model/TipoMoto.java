package ec.edu.espe.ms_clientes.model;

public enum TipoMoto {
    SPORT,
    CRUISER,
    TOURING,
    SCOOTER,
    DOBLE_PROPOSITO

}
